package com.optum.tdsaas.pcarequestapi.repository;

import com.optum.tdsaas.pcarequestapi.model.PCARequest;
import org.springframework.data.repository.CrudRepository;

public interface RequestRepository extends CrudRepository<PCARequest,Long> {


}
