package com.optum.tdsaas.pcarequestapi.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "PCA_Request_Table")
public class PCARequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonIgnore
    private Long  id;
    @Column(name="Request_Id")
    private String requestId;
    @Column(name="Entry_Date")
    private Date entryDate;
    @Column(name="Request_Medium")
    private String requestMedium;
    @Column(name="Request_Status")
    private String requestStatus;
    @Column(name="Request_Notes")
    private String requestNotes;


    public PCARequest(String requestId, Date entryDate, String requestMedium, String requestStatus, String requestNotes) {

        this.requestId = requestId;
        this.entryDate = entryDate;
        this.requestMedium = requestMedium;
        this.requestStatus = requestStatus;
        this.requestNotes = requestNotes;
    }

    public PCARequest() {
    }

    public Long  getId() {
        return id;
    }

    public void setId(Long  id) {
        this.id = id;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public Date getEntryDate() {
        return entryDate;
    }

    public void setEntryDate(Date entryDate) {
        this.entryDate = entryDate;
    }

    public String getRequestMedium() {
        return requestMedium;
    }

    public void setRequestMedium(String requestMedium) {
        this.requestMedium = requestMedium;
    }

    public String getRequestStatus() {
        return requestStatus;
    }

    public void setRequestStatus(String requestStatus) {
        this.requestStatus = requestStatus;
    }

    public String getRequestNotes() {
        return requestNotes;
    }

    public void setRequestNotes(String requestNotes) {
        this.requestNotes = requestNotes;
    }

    @Override
    public String toString() {
        return "PCARequest{" +
                "id='" + id + '\'' +
                ", requestId='" + requestId + '\'' +
                ", entryDate=" + entryDate +
                ", requestMedium='" + requestMedium + '\'' +
                ", requestStatus='" + requestStatus + '\'' +
                ", requestNotes='" + requestNotes + '\'' +
                '}';
    }
}
