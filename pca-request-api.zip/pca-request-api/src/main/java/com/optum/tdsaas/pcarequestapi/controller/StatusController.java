package com.optum.tdsaas.pcarequestapi.controller;

import com.optum.tdsaas.pcarequestapi.model.PCARequest;
import com.optum.tdsaas.pcarequestapi.repository.RequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@RestController
public class StatusController {

    @Autowired
    private RequestRepository requestRepository;

    @GetMapping(path = "/requests")
    public PCARequest getRequests(){

        Date date = new Date();
        return new PCARequest("3",date,"Web","S","All well.");
    }

    @PostMapping(path = "/requests")
    public PCARequest postRequest(PCARequest pcaRequest){

        System.out.println("Post was called....");
        requestRepository.save(pcaRequest);


        System.out.println(pcaRequest.toString());
        return pcaRequest;

    }

    @GetMapping("/dbrequests")
    public List<PCARequest> getAllrequests() {
//
//        Date date = new Date();
//        PCARequest req = new PCARequest("3",date,"Web","S","All well.");
//        requestRepository.save(req);

        return (List<PCARequest>) requestRepository.findAll();
    }
}
