package com.optum.tdsaas.pcarequestapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PcaRequestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
